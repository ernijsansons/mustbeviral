# Must Be Viral - Exported Project

This is an exported version of the Must Be Viral AI-powered content creation platform.

## Project Structure

- `src/` - Main application source code
- `src/lib/` - Core libraries and services
- `src/components/` - React components
- `src/agents/` - AI agent implementations
- `src/app/` - Next.js app router pages and API routes
- `__tests__/` - Test files (unit and e2e)
- `supabase/` - Database migrations

## Key Features

1. **AI Agent System** - 6-agent workflow for content creation
2. **Gamification** - Points, levels, badges, and achievements
3. **Revenue Tools** - Commission tracking for influencers
4. **Analytics** - Real-time engagement tracking
5. **Trend Monitoring** - Google Trends integration
6. **Security** - Bias detection and compliance checking

## Setup Instructions

1. Install dependencies: `npm install`
2. Set up environment variables (see .env.example if provided)
3. Configure Supabase database using the migration files
4. Run development server: `npm run dev`

## Testing

- Unit tests: `npm run test:unit`
- E2E tests: `npm run test:e2e`
- All tests: `npm test`

## Deployment

The project is configured for Cloudflare Workers deployment using Wrangler.

Export created on: 2025-08-22T23:08:57.110Z
